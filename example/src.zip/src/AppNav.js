import React, { useEffect } from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './Home'
import Profile from './Profile'
import TestScreen from './TestScreen'
import CartScreen from './CartScreen'
const Stack = createNativeStackNavigator();
import PushNotification from "react-native-push-notification";
import PushNotificationIOS from '@react-native-community/push-notification-ios';
import { setApnFcmTokenEx, registerEx, RegisterDevice, dataClearEx, sendDataEX, loadCampaignIdByEx, enableAnalyticEx, openWalletEx, disableGluSdkEx, configureLoaderColourEx, enablePrecachingEx, gluSDKDebuggingModeEx, enableEntryPointsEx, closeWebViewEx, isFcmApnEx, configureSafeAreaEx, SetDefaultBannerImageEx, UpdateProfileEx, DisplayCustomerGluNotificationEx, CGApplicationEx, DisplayBackGroundNotificationEx, GetRefferalIdEx, LoadAllCampaginsEx, LoadCampaginsByFilterEx, SetCurrentClassNameEx, OpenWalletWithUrlEx, configureWhiteListedDomainsEx, configureDomainCodeMsgEx } from 'react-native-rncustomerglu';
import AsyncStorage from '@react-native-async-storage/async-storage'
import { requestUserPermission, notificationListner } from './NotificationServices'
import { Platform } from 'react-native';

PushNotification.configure({
    onRegister: async function (token) {
        console.log("TOKEN:---", token.token);
        await AsyncStorage.setItem('apnTokenRegister', token.token);


    },
    // calling

    // (required) Called when a remote is received or opened, or local notification is opened
    onNotification: function (notification) {
        console.log("NOTIFICATION----: onNotification", notification);
        console.log('notification.foreground', notification.foreground)
        if (notification.foreground) {

            console.log("Notification data123", notification.data);
            DisplayBackGroundNotificationEx({ "glu_campaign_id": "a8e22726-5437-4b37-855f-a3f6ed9ec5c4", "glu_push_message_content": { "body": "Check to see how much you've won 🙌", "title": "Order Placed! 😍", "cta_button_link": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDk2MDA5LCJleHAiOjE2OTAwMzIwMDl9.Q_ylP_20jIsS-hmpiWE86pdzqRb9hJf9IbrRuyrEbcs", "cta_button_text": "wallet page", "deeplink": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDk2MDA5LCJleHAiOjE2OTAwMzIwMDl9.Q_ylP_20jIsS-hmpiWE86pdzqRb9hJf9IbrRuyrEbcs", "image": "" }, "glu_message_source": "", "glu_client_id": "84acf2ac-b2e0-4927-8653-cba2b83816c2", "glu_inapp_message_content": { "page_name": "", "page_details": { "body": "Check to see how much you've won 🙌", "title": "Order Placed! 😍", "cta_button_link": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDk2MDA5LCJleHAiOjE2OTAwMzIwMDl9.Q_ylP_20jIsS-hmpiWE86pdzqRb9hJf9IbrRuyrEbcs", "cta_button_text": "wallet page", "image": "" }, "page_type": "full-default", "page_accent": "default" }, "glu_message_type": "push", "glu_user_id": "neha_test_100", "type": "CustomerGlu" })
            // DisplayBackGroundNotificationEx({ "glu_campaign_id": "a8e22726-5437-4b37-855f-a3f6ed9ec5c4", "glu_push_message_content": { "body": "Check to see how much you've won 🙌", "title": "Order Placed! 😍", "cta_button_link": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDkwNTQzLCJleHAiOjE2OTAwMjY1NDN9.gx6ZERKnCpkRjjxzsO-zIXEOP78z19l0h89UmNaFiVg", "image": "", "deeplink": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDkwNTQzLCJleHAiOjE2OTAwMjY1NDN9.gx6ZERKnCpkRjjxzsO-zIXEOP78z19l0h89UmNaFiVg", "cta_button_text": "wallet page" }, "glu_message_source": "", "glu_inapp_message_content": { "page_type": "middle-default", "page_details": { "body": "Check to see how much you've won 🙌", "title": "Order Placed! 😍", "cta_button_link": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDkwNTQzLCJleHAiOjE2OTAwMjY1NDN9.gx6ZERKnCpkRjjxzsO-zIXEOP78z19l0h89UmNaFiVg", "cta_button_text": "wallet page", "image": "" }, "page_name": "", "page_accent": "default" }, "type": "CustomerGlu", "glu_message_type": "push", "glu_client_id": "84acf2ac-b2e0-4927-8653-cba2b83816c2", "glu_user_id": "neha_test_100" })
        }

    },

    // (optional) Called when Registered Action is pressed and invokeApp is false, if true onNotification will be called (Android)
    onAction: function (notification) {
        console.log("ACTION:", notification.action);
        console.log("NOTIFICATION: onAction", notification);
        // DisplayBackGroundNotificationEx(notification.data)
        // process the action
    },

    // (optional) Called when the user fails to register for remote notifications. Typically occurs when APNS is having issues, or the device is a simulator. (iOS)
    onRegistrationError: function (err) {
        console.error(err.message, err);
    },

    // IOS ONLY (optional): default: all - Permissions to register.
    permissions: {
        alert: true,
        badge: true,
        sound: true,
    },
    popInitialNotification: true,
    requestPermissions: true,
});

const App = () => {

    useEffect(() => {
        const type = 'notification';
        if (Platform.OS === 'ios') {

            PushNotificationIOS.addEventListener(type, onRemoteNotification);
            requestUserPermission();
            notificationListner();
        }
        return () => {
            PushNotificationIOS.removeEventListener(type);
        };

    }, [])

    const onRemoteNotification = (notification) => {
        const isClicked = notification.getData().userInteraction === 1;
        console.log("isClicked onRemoteNotification", notification.getData());
        console.log("isClicked", isClicked);
        if (isClicked) {
            console.log("isClicked", isClicked);
            // DisplayBackGroundNotificationEx(notification.getData().data) // DisplayBackGroundNotificati

            // Navigate user to another screen
        } else {
            // Do something else with push notification
        }
    };
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName={'HomeScreen'}>

                <Stack.Screen
                    name="HomeScreen"
                    component={HomeScreen}
                    options={{ title: 'HomeScreen', headerBackVisible: false }}
                    headerBackVisible={false}


                />

                <Stack.Screen
                    name="CartScreen"
                    component={CartScreen}
                    options={{ title: 'CartScreen' }}

                />
                <Stack.Screen
                    name="TestScreen"
                    component={TestScreen}
                    options={{ title: 'TestScreen' }}

                />
            </Stack.Navigator>
        </NavigationContainer>
    );
};

export default App;




// <NavigationContainer>
// <Stack.Navigator initialRouteName={'Home'}>
//     <Stack.Screen
//         name="Home"
//         component={HomeScreen}
//         options={{ title: 'Home' }}
//     />
//     <Stack.Screen
//         name="Profile"
//         component={Profile}
//         options={{ title: 'Profile' }}
//     />
//     <Stack.Screen
//         name="TestScreen"
//         component={TestScreen}
//         options={{ title: 'TestScreen' }}
//     />
//     <Stack.Screen
//         name="CartScreen"
//         component={CartScreen}
//         options={{ title: 'CartScreen' }}

//     />
// </Stack.Navigator>
// </NavigationContainer>