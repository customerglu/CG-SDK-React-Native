import messaging from '@react-native-firebase/messaging';
import AsyncStorage from '@react-native-async-storage/async-storage'
import { setApnFcmTokenEx, DisplayBackGroundNotificationEx, CGApplicationEx } from 'react-native-rncustomerglu'
import PushNotification from 'react-native-push-notification';
import { Platform } from 'react-native';
export async function requestUserPermission() {
    const authStatus = await messaging().requestPermission();
    const enabled =
        authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
        authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
        console.log('Authorization status:', authStatus);
        getFcmToken()
    }
}


const getFcmToken = async () => {
    try {
        const fcmTokenfcm = await messaging().getToken()
        await AsyncStorage.setItem('fcmTokenFCM', fcmTokenfcm);
        console.log("fcm token generated", fcmTokenfcm)

        // --------------------If setApnFcmTokenEx((token.token, "")) for apn is commented uncomment below line -------------

        if (Platform.OS === 'ios') {
            setApnFcmTokenEx("", fcmTokenfcm);
        }


    } catch (error) {
        console.log("error in fcm", error)
    }
}

export const notificationListner = async () => {


    messaging().setBackgroundMessageHandler(async remoteMessage => {
        console.log('Message handled in the background!', remoteMessage);
    });

    messaging().onMessage(async remoteMessage => {

        console.log('A new FCM message arrived!', remoteMessage);
        console.log("remoteMessage", remoteMessage.data.data)

        // DisplayBackGroundNotificationEx(remoteMessage.data);
        PushNotification.localNotification({
            userInfo: {
                data: remoteMessage.data,
            },
            // userInfo: remoteMessage.data,
            title: JSON.stringify(remoteMessage.data),
            message: JSON.stringify(remoteMessage.data),
            // data: JSON.stringify(remoteMessage.data.data),
            // title: remoteMessage.notification.title,
            // message: JSON.stringify(remoteMessage.data.data)

        });

    });




    messaging().onNotificationOpenedApp(remoteMessage => {
        console.log("onNotificationOpenedApp--------", remoteMessage.notification);
        DisplayBackGroundNotificationEx(remoteMessage.notification);
        DisplayBackGroundNotificationEx({ "glu_campaign_id": "a8e22726-5437-4b37-855f-a3f6ed9ec5c4", "glu_push_message_content": { "body": "Check to see how much you've won 🙌", "title": "Order Placed! 😍", "cta_button_link": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDk2MDA5LCJleHAiOjE2OTAwMzIwMDl9.Q_ylP_20jIsS-hmpiWE86pdzqRb9hJf9IbrRuyrEbcs", "cta_button_text": "wallet page", "deeplink": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDk2MDA5LCJleHAiOjE2OTAwMzIwMDl9.Q_ylP_20jIsS-hmpiWE86pdzqRb9hJf9IbrRuyrEbcs", "image": "" }, "glu_message_source": "", "glu_client_id": "84acf2ac-b2e0-4927-8653-cba2b83816c2", "glu_inapp_message_content": { "page_name": "", "page_details": { "body": "Check to see how much you've won 🙌", "title": "Order Placed! 😍", "cta_button_link": "https://democlient.end-ui.customerglu.com/wallet/?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJuZWhhX3Rlc3RfMTAwIiwiY2xpZW50IjoiODRhY2YyYWMtYjJlMC00OTI3LTg2NTMtY2JhMmI4MzgxNmMyIiwiaWF0IjoxNjU4NDk2MDA5LCJleHAiOjE2OTAwMzIwMDl9.Q_ylP_20jIsS-hmpiWE86pdzqRb9hJf9IbrRuyrEbcs", "cta_button_text": "wallet page", "image": "" }, "page_type": "full-default", "page_accent": "default" }, "glu_message_type": "push", "glu_user_id": "neha_test_100", "type": "CustomerGlu" })

        // CGApplicationEx(remoteMessage.notification);
        console.log('notification caused App to open from background:', remoteMessage.notification);

    });

    // messaging().getInitialNotification().then(remoteMessage => {
    //     if (remoteMessage) {
    //         PushNotification.localNotification({
    //             message: remoteMessage.notification.body,
    //             title: remoteMessage.notification.title,

    //         });
    //         console.log('notification from quit state', remoteMessage.notification);
    //         console.log("remote message", remoteMessage.notification)
    //     }

    // });

    // messaging().onMessage(remoteMessage => {
    //     PushNotification.localNotification({
    //         message: remoteMessage.notification.body,
    //         title: remoteMessage.notification.title,

    //     });

    //     // console.log("three", remoteMessage.notification.body)
    //     // DisplayBackGroundNotificationEx(remoteMessage.notification);
    //     // CGApplicationEx(remoteMessage.notification.data);
    //     console.log("forground", remoteMessage.notification)
    // })


}